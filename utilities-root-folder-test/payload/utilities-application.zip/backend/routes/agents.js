const express = require('express');
const db = require('../config/database');
const native = require('../lib/nativeSelectAi');
const router = express.Router();
const teams = ['GRID_RELIABILITY_TEAM', 'FIELD_CREW_LOGISTICS_TEAM', 'UTILITY_SERVICE_REQUEST_TEAM'];

router.get('/teams', (_req, res) => res.json(teams.map((TEAM_NAME) => ({ TEAM_NAME, STATUS: 'ENABLED' }))));
router.get('/profiles', (_req, res) => res.json({
  profiles: [{
    name: native.PROFILE,
    status: 'ENABLED',
    model: native.MODEL,
    provider: 'OCI Generative AI',
    type: 'OCI Generative AI via DBMS_CLOUD_AI_AGENT',
  }],
  activeProfile: native.PROFILE,
}));
router.post('/set-profile', (_req, res) => res.json({ success: true, profile: native.PROFILE }));
router.get('/actions', async (req, res) => {
  const parsedLimit = Number.parseInt(req.query.limit, 10);
  const limit = Math.max(1, Math.min(Number.isFinite(parsedLimit) ? parsedLimit : 10, 100));
  try {
    const result = await db.execute(
      `SELECT action_id, agent_name, action_type, entity_type, entity_id,
              decision_payload, confidence, execution_status, created_at, executed_at
         FROM agent_actions
        ORDER BY created_at DESC
        FETCH FIRST :limit ROWS ONLY`,
      { limit }
    );
    return res.json(result.rows || []);
  } catch (error) {
    return res.status(error.statusCode || 503).json({ code: error.code, error: 'Agent action history is unavailable.' });
  }
});
router.post('/chat', async (req, res) => {
  const startedAt = Date.now();
  try {
    const question = req.body?.question;
    const result = await native.runAgentTeam(question, req.demoUser, { team: req.body?.team });
    return res.json({
      ...result,
      teamName: result.team,
      conversationId: 'native-' + Date.now(),
      intent: 'native-advisory',
      agentUsed: true,
      toolsUsed: result.agentToolsUsed,
      data: result.rows,
      elapsed: Date.now() - startedAt,
    });
  } catch (error) {
    return res.status(error.statusCode || 500).json({ code: error.code, error: error.message });
  }
});
module.exports = router;
