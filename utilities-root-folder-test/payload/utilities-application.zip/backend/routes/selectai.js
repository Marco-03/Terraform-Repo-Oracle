const express = require('express');
const native = require('../lib/nativeSelectAi');

const router = express.Router();
const SCHEMA_OBJECTS = [...native.ALLOWED_OBJECTS].map((objectName) => ({
  object_name: objectName.toLowerCase(),
  object_type: 'view',
  is_queryable_by_assistant: true,
  domain: objectName.includes('RELIABILITY') ? 'Reliability, Production & Compliance' : 'Utilities Operations',
}));

function questionFrom(req) {
  return String(req.body?.question || '').trim();
}

function errorPayload(error, startedAt, action) {
  return {
    error: error.message || 'ADB native AI could not complete the request.',
    category: error.category || error.code || 'NATIVE_AI_UNAVAILABLE',
    profile: native.PROFILE,
    model: native.MODEL,
    region: native.REGION,
    provider: 'OCI Generative AI',
    action,
    sql: error.category === 'SQL_VALIDATION_BLOCKED' ? null : error.sql || null,
    elapsed: Date.now() - startedAt,
    ready: false,
  };
}

function sendError(res, error, startedAt, action) {
  return res.status(error.statusCode || 503).json(errorPayload(error, startedAt, action));
}

router.get('/profiles', async (req, res) => {
  const startedAt = Date.now();
  try {
    const readiness = await native.checkReadiness(req.demoUser);
    return res.json({
      profiles: [{ name: native.PROFILE, status: 'ENABLED', model: native.MODEL, provider: 'OCI Generative AI', type: 'Governed native Select AI' }],
      activeProfile: native.PROFILE,
      readiness,
    });
  } catch (error) {
    return sendError(res, error, startedAt, 'READINESS');
  }
});

router.get('/schema-objects', (_req, res) => res.json({ objects: SCHEMA_OBJECTS }));

router.get('/health', async (req, res) => {
  const startedAt = Date.now();
  try {
    return res.json(await native.checkReadiness(req.demoUser));
  } catch (error) {
    return sendError(res, error, startedAt, 'READINESS');
  }
});

async function narrative(req, res, mode) {
  const startedAt = Date.now();
  try {
    const result = await native.answerQuestion(questionFrom(req), req.demoUser, { mode, history: req.body?.history });
    return res.json({
      question: questionFrom(req), answer: result.answer, keyFindings: [], resultSummary: '', followUpQuestions: [],
      referencedData: result.referencedData, rowCount: result.rowCount, sql: req.body?.showSql === false ? null : result.sql,
      elapsed: Date.now() - startedAt, profile: result.profile, model: result.model, region: result.region,
      provider: result.provider, action: result.action, readOnly: true, evidence: native.evidence(result.action, { generatedSql: true, executed: true, rowCount: result.rowCount, truncated: result.truncated }),
    });
  } catch (error) {
    return sendError(res, error, startedAt, 'SHOWSQL + RUNSQL + CHAT');
  }
}

router.post('/chat', (req, res) => narrative(req, res, 'narrate'));
router.post('/chat-mode', (req, res) => narrative(req, res, 'chat'));

router.post('/showsql', async (req, res) => {
  const startedAt = Date.now();
  try {
    const result = await native.generateQuestionSql(questionFrom(req), req.demoUser);
    return res.json({
      question: questionFrom(req), sql: result.sql, explanation: 'OCI Generative AI generated this single read-only query for review. It was not executed.',
      elapsed: Date.now() - startedAt, profile: result.profile, model: result.model, region: result.region, provider: result.provider,
      action: result.action, readOnly: true, evidence: native.evidence('SHOWSQL', { generatedSql: true, executed: false }),
    });
  } catch (error) {
    return sendError(res, error, startedAt, 'SHOWSQL');
  }
});

router.post('/runsql', async (req, res) => {
  const startedAt = Date.now();
  try {
    const result = await native.runQuestionQuery(questionFrom(req), req.demoUser);
    return res.json({
      question: questionFrom(req), columns: result.columns, rows: result.rows, rowCount: result.rowCount, truncated: result.truncated,
      sql: result.sql, explanation: `${result.rowCount} row${result.rowCount === 1 ? '' : 's'} returned from the validated read-only Select AI query.`,
      elapsed: Date.now() - startedAt, profile: result.profile, model: result.model, region: result.region, provider: result.provider,
      action: result.action, readOnly: true, evidence: native.evidence('RUNSQL', { generatedSql: true, executed: true, rowCount: result.rowCount, truncated: result.truncated }),
    });
  } catch (error) {
    return sendError(res, error, startedAt, 'RUNSQL');
  }
});

module.exports = router;
