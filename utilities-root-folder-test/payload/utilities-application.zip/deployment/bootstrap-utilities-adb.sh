#!/usr/bin/env bash
# Resource Manager ADB handoff for Energy & Utilities.  This intentionally
# replaces the donor's local Oracle-Free container bootstrap.
set -Eeuo pipefail

SOURCE_DIR="${UTILITIES_SOURCE_DIR:-/opt/utilities-livestack/application}"
WALLET_ARCHIVE="${WALLET_ARCHIVE:?missing wallet}"
ADB_CONNECT_STRING="${ADB_CONNECT_STRING:?missing ADB service name}"
ADB_ADMIN_PASSWORD="${ADB_ADMIN_PASSWORD:?missing ADB ADMIN password}"
APP_SCHEMA_PASSWORD="${APP_SCHEMA_PASSWORD:?missing APP_USER password}"
MODEL_OBJECT_URI="${MODEL_OBJECT_URI:?missing model object URI}"
OCI_TENANCY_OCID="${OCI_TENANCY_OCID:?missing tenancy OCID}"
OCI_USER_OCID="${OCI_USER_OCID:?missing user OCID}"
OCI_COMPARTMENT_OCID="${OCI_COMPARTMENT_OCID:?missing compartment OCID}"
OCI_GENAI_REGION="${OCI_GENAI_REGION:?missing GenAI region}"
OCI_GENAI_MODEL_ID="${OCI_GENAI_MODEL_ID:?missing GenAI model}"
OCI_API_KEY_FINGERPRINT="${OCI_API_KEY_FINGERPRINT:?missing API-key fingerprint}"
OCI_API_PRIVATE_KEY_FILE="${OCI_API_PRIVATE_KEY_FILE:?missing API private key}"
WORK_DIR="$(mktemp -d /tmp/utilities-adb.XXXXXX)"

fail() { printf '[utilities-adb] %s\n' "$*" >&2; exit 1; }
[[ -d "${SOURCE_DIR}/db/schema" ]] || fail 'Utilities schema source is missing.'
[[ -s "${WALLET_ARCHIVE}" ]] || fail 'ADB wallet is missing.'
[[ "${ADB_CONNECT_STRING}" =~ ^[A-Za-z][A-Za-z0-9_]{0,63}$ ]] || fail 'ADB service name is invalid.'
[[ "${APP_SCHEMA_PASSWORD}" =~ ^[A-Za-z0-9]{12,30}$ ]] || fail 'APP_USER password is invalid.'
[[ "${MODEL_OBJECT_URI}" == https://* ]] || fail 'Model object URI must use HTTPS.'
command -v sql >/dev/null 2>&1 || fail 'SQLcl is required.'

completion_marker_present() {
  local marker="$1"
  local output="$2"
  local normalized_output

  # SQLcl 26.2 may render a PROMPT through JLine with whitespace between its
  # characters when cloud-init has no attached terminal. Strip presentation
  # characters only for the completion-marker check; Oracle/SQLcl errors above
  # are always checked against the unmodified log.
  normalized_output="$(LC_ALL=C tr -cd '[:alnum:]_' < "${output}")"
  [[ "${normalized_output}" == *"${marker}"* ]]
}

run_sqlcl() {
  local account="$1"
  local password="$2"
  local driver="$3"
  local marker="$4"
  local output="${WORK_DIR}/${marker}.log"
  set +e
  { printf '%s\n' "${password}"; cat "${driver}"; } |
    sql -S -L -nohistory -noupdates -cloudconfig "${WALLET_ARCHIVE}" "${account}@${ADB_CONNECT_STRING}" >"${output}" 2>&1
  local exit_code=$?
  set -e
  if [[ "${exit_code}" -ne 0 ]] ||
     grep -Eiq '(ORA-[0-9]{5}|PLS-[0-9]{5}|SP2-[0-9]{4}|SQLcl:[[:space:]]*Error|Error starting at line)' "${output}"; then
    printf 'UTILITIES_SQL_PHASE=%s\n' "${marker}" >&2
    grep -Eo 'UTILITIES_SQL_STEP=[A-Za-z0-9_.-]+' "${output}" | tail -n 1 >&2 || true
    grep -Eom1 '(ORA|PLS|SP2)-[0-9]{4,5}' "${output}" >&2 || true
    fail "SQLcl phase ${marker} failed."
  fi
  completion_marker_present "${marker}" "${output}" ||
    fail "SQLcl phase ${marker} did not complete."
}

admin_sql="${WORK_DIR}/admin.sql"
cat >"${admin_sql}" <<SQL
SET ECHO OFF VERIFY OFF DEFINE OFF SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
DECLARE n PLS_INTEGER; BEGIN
  SELECT COUNT(*) INTO n FROM dba_users WHERE username = 'APP_USER';
  IF n > 0 THEN EXECUTE IMMEDIATE 'DROP USER APP_USER CASCADE'; END IF;
  EXECUTE IMMEDIATE 'CREATE USER APP_USER IDENTIFIED BY "${APP_SCHEMA_PASSWORD}" QUOTA UNLIMITED ON DATA';
END;
/
BEGIN
  DBMS_CLOUD.GET_OBJECT(object_uri => '${MODEL_OBJECT_URI}', directory_name => 'DATA_PUMP_DIR', file_name => 'all_MiniLM_L12_v2.onnx');
  DBMS_VECTOR.LOAD_ONNX_MODEL(directory => 'DATA_PUMP_DIR', file_name => 'all_MiniLM_L12_v2.onnx', model_name => 'ALL_MINILM_L12_V2');
EXCEPTION WHEN OTHERS THEN IF SQLCODE != -20400 THEN RAISE; END IF; END;
/
GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW, CREATE SEQUENCE, CREATE PROCEDURE, CREATE TRIGGER, CREATE TYPE, CREATE JOB, CREATE MINING MODEL, UNLIMITED TABLESPACE TO APP_USER;
GRANT SODA_APP, GRAPH_DEVELOPER TO APP_USER;
GRANT EXECUTE ON DBMS_CLOUD TO APP_USER;
GRANT EXECUTE ON DBMS_CLOUD_AI TO APP_USER;
GRANT EXECUTE ON DBMS_CLOUD_AI_AGENT TO APP_USER;
GRANT EXECUTE ON SYS.DBMS_RLS TO APP_USER;
GRANT EXECUTE ON SYS.DBMS_VECTOR TO APP_USER;
GRANT EXECUTE ON SYS.DBMS_DATA_MINING TO APP_USER;
GRANT EXECUTE ON SYS.DBMS_XPLAN TO APP_USER;
GRANT EXECUTE ON MDSYS.SDO_GEOM TO APP_USER;
GRANT EXECUTE ON MDSYS.SDO_UTIL TO APP_USER;
GRANT EXECUTE ON MDSYS.SDO_CS TO APP_USER;
GRANT SELECT ON MINING MODEL ADMIN.ALL_MINILM_L12_V2 TO APP_USER;
DECLARE
  PROCEDURE ensure_role(p_role_name IN VARCHAR2) IS
  BEGIN
    EXECUTE IMMEDIATE 'CREATE ROLE ' || p_role_name;
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE != -1921 THEN RAISE; END IF;
  END;
BEGIN
  ensure_role('SC_ADMIN');
  ensure_role('SC_ANALYST');
  ensure_role('SC_FULFILLMENT_MGR');
  ensure_role('SC_FIELD_SUPERVISOR');
  ensure_role('SC_VIEWER');
END;
/
PROMPT UTILITIES_ADMIN_READY
EXIT SUCCESS
SQL
run_sqlcl ADMIN "${ADB_ADMIN_PASSWORD}" "${admin_sql}" UTILITIES_ADMIN_READY

awk '/-- PRODUCT EMBEDDINGS/{found=1; next} found {print}' "${SOURCE_DIR}/db/schema/04_vector.sql" >"${WORK_DIR}/04_vector.sql"
awk '/-- SECTION 2A: TRUSTED SECURITY PACKAGE/{found=1; next} /-- SECTION 2B: VPD POLICIES AND AUDIT/{exit} found {print}' "${SOURCE_DIR}/db/schema/06_security.sql" >"${WORK_DIR}/06_package.sql"
awk '/-- SECTION 2B: VPD POLICIES AND AUDIT/{found=1; next} found {print}' "${SOURCE_DIR}/db/schema/06_security.sql" >"${WORK_DIR}/06_policies.sql"
[[ -s "${WORK_DIR}/04_vector.sql" && -s "${WORK_DIR}/06_package.sql" && -s "${WORK_DIR}/06_policies.sql" ]] || fail 'Required Utilities SQL sections could not be extracted.'

app_base_sql="${WORK_DIR}/app-base.sql"
cat >"${app_base_sql}" <<SQL
SET ECHO OFF VERIFY OFF DEFINE OFF SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
PROMPT UTILITIES_SQL_STEP=01_tables
@${SOURCE_DIR}/db/schema/01_tables.sql
PROMPT UTILITIES_SQL_STEP=02_json_collections
@${SOURCE_DIR}/db/schema/02_json_collections.sql
PROMPT UTILITIES_SQL_STEP=03_graph
@${SOURCE_DIR}/db/schema/03_graph.sql
PROMPT UTILITIES_SQL_STEP=04_vector
@${WORK_DIR}/04_vector.sql
PROMPT UTILITIES_SQL_STEP=05_spatial
@${SOURCE_DIR}/db/schema/05_spatial.sql
PROMPT UTILITIES_SQL_STEP=10_service_restoration_graph
@${SOURCE_DIR}/db/schema/10_service_restoration_graph.sql
PROMPT UTILITIES_SQL_STEP=11_utilities_semantic_views
@${SOURCE_DIR}/db/schema/11_utilities_semantic_views.sql
PROMPT UTILITIES_SQL_STEP=load_all_data
@${SOURCE_DIR}/db/data/load_all_data.sql
PROMPT UTILITIES_SQL_STEP=06_security_package
@${WORK_DIR}/06_package.sql
PROMPT UTILITIES_APP_BASE_READY
EXIT SUCCESS
SQL
run_sqlcl APP_USER "${APP_SCHEMA_PASSWORD}" "${app_base_sql}" UTILITIES_APP_BASE_READY

security_sql="${WORK_DIR}/security.sql"
context_admin_sql="${WORK_DIR}/06a_utilities_app_context_admin.sql"
# This source file is also usable as a standalone SQLcl script and therefore
# ends in EXIT SUCCESS.  Remove only that terminator for the nested ADMIN
# driver, otherwise SQLcl exits before its phase marker is emitted.
sed -E '/^[[:space:]]*EXIT[[:space:]]+SUCCESS[[:space:]]*$/Id' \
  "${SOURCE_DIR}/db/schema/06a_utilities_app_context_admin.sql" >"${context_admin_sql}"
[[ -s "${context_admin_sql}" ]] || fail 'Application-context ADMIN SQL is empty.'
cat >"${security_sql}" <<SQL
SET ECHO OFF VERIFY OFF DEFINE ON SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
@${context_admin_sql} APP_USER
@${SOURCE_DIR}/db/schema/16_utilities_unified_audit_admin.sql APP_USER
PROMPT UTILITIES_SECURITY_ADMIN_READY
EXIT SUCCESS
SQL
run_sqlcl ADMIN "${ADB_ADMIN_PASSWORD}" "${security_sql}" UTILITIES_SECURITY_ADMIN_READY

app_final_sql="${WORK_DIR}/app-final.sql"
cat >"${app_final_sql}" <<SQL
SET ECHO OFF VERIFY OFF DEFINE OFF SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
@${WORK_DIR}/06_policies.sql
BEGIN utilities_security_pkg.set_actor_context('admin_jess'); END;
/
PROMPT UTILITIES_SQL_STEP=finalize_vector_search
@${SOURCE_DIR}/db/data/finalize_vector_search.sql
PROMPT UTILITIES_SQL_STEP=hydrate_spatial_points
@${SOURCE_DIR}/db/data/hydrate_spatial_points.sql
PROMPT UTILITIES_SQL_STEP=seed_fulfillment_zones
@${SOURCE_DIR}/db/data/seed_fulfillment_zones.sql
BEGIN utilities_security_pkg.clear_actor_context; END;
/
PROMPT UTILITIES_SQL_STEP=load_service_restoration_graph
@${SOURCE_DIR}/db/data/load_service_restoration_graph.sql
PROMPT UTILITIES_SQL_STEP=11_utilities_semantic_views
@${SOURCE_DIR}/db/schema/11_utilities_semantic_views.sql
PROMPT UTILITIES_SQL_STEP=12_oml_models
@${SOURCE_DIR}/db/schema/12_oml_models.sql
PROMPT UTILITIES_SQL_STEP=13_dataset_generation_lifecycle
@${SOURCE_DIR}/db/schema/13_dataset_generation_lifecycle.sql
PROMPT UTILITIES_ADB_PROVISIONING_OK
EXIT SUCCESS
SQL
run_sqlcl APP_USER "${APP_SCHEMA_PASSWORD}" "${app_final_sql}" UTILITIES_ADB_PROVISIONING_OK

native_ai_sql="${WORK_DIR}/native-ai.sql"
cat >"${native_ai_sql}" <<SQL
SET ECHO OFF VERIFY OFF DEFINE OFF SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
DBCC CREATE UTIL_GENAI_KEY_V1 fingerprint ${OCI_API_KEY_FINGERPRINT} user_ocid ${OCI_USER_OCID} tenancy_ocid ${OCI_TENANCY_OCID} private_path ${OCI_API_PRIVATE_KEY_FILE}
PROMPT UTILITIES_SQL_STEP=native_credential

DECLARE
  l_attributes CLOB;
BEGIN
  BEGIN DBMS_CLOUD_AI.DROP_PROFILE('UTILITIES_SELECTAI_V1'); EXCEPTION WHEN OTHERS THEN NULL; END;
  SELECT JSON_OBJECT(
    'provider' VALUE 'oci',
    'credential_name' VALUE 'UTIL_GENAI_KEY_V1',
    'oci_compartment_id' VALUE '${OCI_COMPARTMENT_OCID}',
    'region' VALUE '${OCI_GENAI_REGION}',
    'model' VALUE '${OCI_GENAI_MODEL_ID}',
    'oci_apiformat' VALUE 'COHERE',
    'temperature' VALUE 0,
    'comments' VALUE true,
    'object_list' VALUE JSON_ARRAY(
      JSON_OBJECT('owner' VALUE USER, 'name' VALUE 'SERVICE_POINTS_V'),
      JSON_OBJECT('owner' VALUE USER, 'name' VALUE 'UTILITY_SERVICES_V'),
      JSON_OBJECT('owner' VALUE USER, 'name' VALUE 'UTILITY_REQUEST_ITEMS'),
      JSON_OBJECT('owner' VALUE USER, 'name' VALUE 'RELIABILITY_LOAD_SIGNALS_V'),
      JSON_OBJECT('owner' VALUE USER, 'name' VALUE 'UTILITY_SERVICE_REQUESTS_V'),
      JSON_OBJECT('owner' VALUE USER, 'name' VALUE 'FIELD_LOGISTICS_SITES_V'),
      JSON_OBJECT('owner' VALUE USER, 'name' VALUE 'ASSET_CAPACITY_V'),
      JSON_OBJECT('owner' VALUE USER, 'name' VALUE 'OPERATIONAL_EVENT_EVIDENCE_V')
    ) RETURNING CLOB
  ) INTO l_attributes FROM dual;
  DBMS_CLOUD_AI.CREATE_PROFILE('UTILITIES_SELECTAI_V1', l_attributes, 'ENABLED', 'Governed Utilities Select AI profile');
END;
/
PROMPT UTILITIES_SQL_STEP=native_profile

DECLARE
BEGIN
  -- Runtime tasks intentionally have no tools.  The sole SQL tool in the
  -- conversion contract is reserved for bootstrap acceptance and is never
  -- attached to an agent task.
  DBMS_CLOUD_AI_AGENT.CREATE_AGENT('GRID_RELIABILITY_AGENT',
    '{"profile_name":"UTILITIES_SELECTAI_V1","role":"Provide advisory grid and reliability analysis only."}',
    'ENABLED', 'Utilities grid reliability advisor');
  DBMS_CLOUD_AI_AGENT.CREATE_AGENT('FIELD_CREW_LOGISTICS_AGENT',
    '{"profile_name":"UTILITIES_SELECTAI_V1","role":"Provide advisory field logistics analysis only."}',
    'ENABLED', 'Utilities field logistics advisor');
  DBMS_CLOUD_AI_AGENT.CREATE_AGENT('UTILITY_SERVICE_REQUEST_AGENT',
    '{"profile_name":"UTILITIES_SELECTAI_V1","role":"Provide advisory service-request analysis only."}',
    'ENABLED', 'Utilities service request advisor');
  DBMS_CLOUD_AI_AGENT.CREATE_AGENT('UTILITIES_OPERATIONS_SUPERVISOR',
    '{"profile_name":"UTILITIES_SELECTAI_V1","role":"Coordinate advisory Utilities analysis without tools."}',
    'ENABLED', 'Utilities advisory supervisor');
END;
/
PROMPT UTILITIES_SQL_STEP=native_agents

DECLARE
BEGIN
  DBMS_CLOUD_AI_AGENT.CREATE_TASK('GRID_RELIABILITY_TASK',
    '{"instruction":"Provide advisory Utilities reliability analysis for: {query}","tools":[]}', 'ENABLED', 'Tool-free reliability task');
  DBMS_CLOUD_AI_AGENT.CREATE_TASK('FIELD_CREW_LOGISTICS_TASK',
    '{"instruction":"Provide advisory Utilities field logistics analysis for: {query}","tools":[]}', 'ENABLED', 'Tool-free logistics task');
  DBMS_CLOUD_AI_AGENT.CREATE_TASK('UTILITY_SERVICE_REQUEST_TASK',
    '{"instruction":"Answer the Utilities request directly from supplied governed evidence. Give a concise finding, cited evidence, and proposed next actions; never ask the user for more information or a new query.","tools":[]}', 'ENABLED', 'Tool-free service request task');
END;
/
PROMPT UTILITIES_SQL_STEP=native_tasks

DECLARE
BEGIN
  DBMS_CLOUD_AI_AGENT.CREATE_TEAM('GRID_RELIABILITY_TEAM',
    '{"agents":[{"name":"GRID_RELIABILITY_AGENT","task":"GRID_RELIABILITY_TASK"}],"process":"sequential"}', 'ENABLED', 'Tool-free reliability team');
  DBMS_CLOUD_AI_AGENT.CREATE_TEAM('FIELD_CREW_LOGISTICS_TEAM',
    '{"agents":[{"name":"FIELD_CREW_LOGISTICS_AGENT","task":"FIELD_CREW_LOGISTICS_TASK"}],"process":"sequential"}', 'ENABLED', 'Tool-free logistics team');
  DBMS_CLOUD_AI_AGENT.CREATE_TEAM('UTILITY_SERVICE_REQUEST_TEAM',
    '{"agents":[{"name":"UTILITY_SERVICE_REQUEST_AGENT","task":"UTILITY_SERVICE_REQUEST_TASK"}],"process":"sequential"}', 'ENABLED', 'Tool-free service request team');
END;
/
PROMPT UTILITIES_SQL_STEP=native_teams
PROMPT UTILITIES_NATIVE_AI_READY
EXIT SUCCESS
SQL
run_sqlcl APP_USER "${APP_SCHEMA_PASSWORD}" "${native_ai_sql}" UTILITIES_NATIVE_AI_READY
